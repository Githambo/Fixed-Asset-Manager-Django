import os
from setuptools import find_packages,setup

with open(os.path.join(os.path.dirname(__file__),'README.rst')) as readme:
	README=readme.read()

os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

setup(
	name='django-asset-manager',
	version='1.0',
	packages=find_packages(),
	licence='BSD Licence',
	description='Asset manager tracking depreciation and retirement',
	long_description=README,
	url='',
	author='Kenneth Githambo',
	author_email='mrgithambo@gmail.com',
	classifiers=[
		'Environment :: Web Environment',
		'Framework :: Django',
		'Framework :: Django :: crispy.markdownify',
		'Operating System :: OS Independent',
		'Programming Language :: Python :: 3.7'
	  ]
	)