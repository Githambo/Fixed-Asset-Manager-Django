=====
Erp for Assets
=====
Erp is a simple django app that maintains company or firm based assets.
It takes new assets ,runs depreciations using straight line method,and being able 
to retire the assest.Its a pretty exiting webapp much related to assetworkbench for Oracle.
Detailed documentation is in the "docs" directory.

Quick start
-----------
1. Add "Erp" to your INSTALLED_APPS setting like this::
INSTALLED_APPS = [
...
'Erp',
]

2. Include the Erp URLconf in your project urls.py like this::
path('Erp/', include('Erp.urls')),

3. Run `python manage.py migrate` to create the Erp models.

4. Start the development server and visit http://127.0.0.1:8000/admin/to Add assets and perfom the operations (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/Erp/ to Enjoy various actions

##any lookup for assets is performed under search Asset